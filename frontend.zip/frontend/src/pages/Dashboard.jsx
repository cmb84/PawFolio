import { useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthProvider";

export default function Dashboard() {
  const { user, loading } = useAuth();
  const nav = useNavigate();

  useEffect(() => {
    if (!loading && !user) nav("/login", { replace: true });
  }, [loading, user, nav]);

  const greeting = useMemo(() => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    return "Good evening";
  }, []);

  if (loading) return null;

  // IMDb image URLs
  const trending = [
    {
      t: "Blade Runner 2049",
      y: 2017,
      img: "https://m.media-amazon.com/images/M/MV5BMjQzMTg4NTAyMV5BMl5BanBnXkFtZTgwNTM3NTM1MzI@._V1_.jpg",
      imdb: "https://www.imdb.com/title/tt1856101/",
    },
    {
      t: "The Dark Knight",
      y: 2008,
      img: "https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMDk2Mw@@._V1_.jpg",
      imdb: "https://www.imdb.com/title/tt0468569/",
    },
    {
      t: "The Godfather",
      y: 1972,
      img: "https://m.media-amazon.com/images/M/MV5BM2MyNjYxNmYtYTAwMC00ZjQ5LWFmNTEtODM1ZmRlN2RhZWRiXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_.jpg",
      imdb: "https://www.imdb.com/title/tt0068646/",
    },
    {
      t: "Joker",
      y: 2019,
      img: "https://m.media-amazon.com/images/M/MV5BM2MyNjYxNmYtYTAwMC00ZjQ5LWFmNTEtODM1ZmRlN2RhZWRiXkEyXkFqcGdeQXVyNjAwNDUxODI@._V1_.jpg",
      imdb: "https://www.imdb.com/title/tt7286456/",
    },
    {
      t: "Spirited Away",
      y: 2001,
      img: "https://m.media-amazon.com/images/M/MV5BYWZjMzQyNmEtZjliNy00OTQ0LWI1OGEtZmQ0ZjcwMTk5MzQ4XkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_.jpg",
      imdb: "https://www.imdb.com/title/tt0245429/",
    },
    {
      t: "Pulp Fiction",
      y: 1994,
      img: "https://m.media-amazon.com/images/M/MV5BNGNhMDIzZTItZmRhMC00ZGEyLWFmNTEtODM1ZmRlN2RhZWRiXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_.jpg",
      imdb: "https://www.imdb.com/title/tt0110912/",
    },
  ];

  const topRated = [
    {
      t: "Schindler’s List",
      y: 1993,
      img: "https://m.media-amazon.com/images/M/MV5BMTAzNjk4NTY2OTReQTJeQWpwZ15BbWU4MDc3MTkwNDEx._V1_.jpg",
      imdb: "https://www.imdb.com/title/tt0108052/",
    },
    {
      t: "The Lord of the Rings: The Return of the King",
      y: 2003,
      img: "https://m.media-amazon.com/images/M/MV5BZjdkOTU3MDAtN2E1ZS00ZjU0LTg4NjAtYWQxN2QzY2Q3NGEzXkEyXkFqcGdeQXVyNDUzOTQ5MjY@._V1_.jpg",
      imdb: "https://www.imdb.com/title/tt0167260/",
    },
    {
      t: "Cloverfield",
      y: 2008,
      img: "https://m.media-amazon.com/images/M/MV5BMjE3NDM2NjY4OV5BMl5BanBnXkFtZTcwODg0NTU2MQ@@._V1_.jpg",
      imdb: "https://www.imdb.com/title/tt1060277/",
    },
    {
      t: "Fight Club",
      y: 1999,
      img: "https://m.media-amazon.com/images/M/MV5BMmEzNjQxYzAtNDQzZC00YTI1LTljYmItZjM0MmE2Y2RhN2MyXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_.jpg",
      imdb: "https://www.imdb.com/title/tt0137523/",
    },
    {
      t: "Interstellar",
      y: 2014,
      img: "https://m.media-amazon.com/images/M/MV5BMjIxMjgxNzM2NF5BMl5BanBnXkFtZTgwNzUxNzE3MjE@._V1_.jpg",
      imdb: "https://www.imdb.com/title/tt0816692/",
    },
  ];

  const MoodChip = ({ label, emoji }) => (
    <button className="mood-chip" type="button">
      <span style={{ marginRight: 8 }}>{emoji}</span>
      {label}
    </button>
  );

  const Poster = ({ m }) => (
    <a href={m.imdb} target="_blank" rel="noopener noreferrer" className="poster-card">
      <img src={m.img} alt={m.t} className="poster-img" loading="lazy" />
      <div className="poster-info">
        <div className="poster-title">{m.t}</div>
        <div className="poster-year">{m.y}</div>
      </div>
    </a>
  );

  return (
    <main className="page dashboard">
      <section className="hero">
        <div className="hero-inner">
          <div className="hero-content">
            <h1 className="hero-title">
              <span className="accent">{greeting}</span>
              {user?.username ? `, ${user.username}` : ""}.
            </h1>
            <h2 className="hero-sub">What’s your <span className="accent">mood</span> today?</h2>

            <div className="mood-bar">
              <MoodChip emoji="😊" label="Happy" />
              <MoodChip emoji="😔" label="Sad" />
              <MoodChip emoji="💘" label="Romantic" />
              <MoodChip emoji="😎" label="Chill" />
              <MoodChip emoji="🧭" label="Adventurous" />
              <button className="btn-cta">Continue →</button>
            </div>
          </div>
        </div>
      </section>

      <section className="movie-section">
        <h3 className="feature-title">Trending Now</h3>
        <div className="poster-grid">
          {trending.map((m) => (
            <Poster key={m.imdb} m={m} />
          ))}
        </div>
      </section>

      <section className="movie-section">
        <h3 className="feature-title">Top Rated Across Platforms</h3>
        <div className="poster-grid">
          {topRated.map((m) => (
            <Poster key={m.imdb} m={m} />
          ))}
        </div>
      </section>
    </main>
  );
}
